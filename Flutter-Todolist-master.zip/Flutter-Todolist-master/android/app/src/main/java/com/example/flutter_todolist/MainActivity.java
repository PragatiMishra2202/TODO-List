package com.example.flutter_todolist;


import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
