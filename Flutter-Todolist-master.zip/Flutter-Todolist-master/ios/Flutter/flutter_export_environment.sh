#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/johan/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/johan/Documents/Projects/interestinate.com/Flutter-Github-repos/Flutter-Todolist"
export "FLUTTER_TARGET=/Users/johan/Documents/Projects/interestinate.com/Flutter-Github-repos/Flutter-Todolist/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_DEFINES=flutter.inspector.structuredErrors%3Dtrue"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/johan/Documents/Projects/interestinate.com/Flutter-Github-repos/Flutter-Todolist/.dart_tool/package_config.json"
